=== EEZZ PIC2CLD Professional ===
Contributors: EEZZ.NET
Donate link: https://eezz.net/
Tags: cloudflare r2, s3 storage, image upload, cropper, batch upload
Requires at least: 5.8
Tested up to: 6.5
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Industrial-grade Cloudflare R2 storage integration. Features a surgical-precision image cropper and industrial batch upload console.

== Description ==

**EEZZ PIC2CLD Professional** is a high-performance infrastructure plugin designed to offload your WordPress Media Library to **Cloudflare R2** (S3-compatible) with zero friction. 

Built for full-stack developers and WooCommerce store owners who demand speed and reliability. This plugin "hijacks" the standard media URL flow, ensuring your assets are served directly from your global CDN.

### Key Features:
*   **Industrial Console:** A dedicated dual-zone dashboard for high-concurrency uploads.
*   **Surgical Cropper:** Built-in Cropper.js integration to refine images before they hit the cloud.
*   **Batch Mode:** Drag-and-drop multiple assets for bulk synchronization.
*   **Native Integration:** Seamlessly works with the WordPress Media Library. Asset metadata is automatically updated to reflect cloud paths.
*   **R2 Optimized:** Uses AWS V4 Signature protocol optimized specifically for Cloudflare R2's architecture.

### Free Version Limitations:
*   Supports **1 active storage bucket** connection.
*   Standard upload protocols.
*   (PRO version available for unlimited buckets and automated migration).

== Installation ==

1. Upload the `eezzpic2cld` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **EEZZ Upload -> Bucket Management** to connect your Cloudflare R2 bucket.
4. Enter your Account ID, Access Key, Secret Key, and Public CDN URL.
5. Start uploading via the **EEZZ Upload** console.

== Frequently Asked Questions ==

= Does this delete local files? =
No. For safety and compliance, this version focuses on direct-to-cloud uploads via the dedicated console.

= Can I use other S3 providers? =
While optimized for Cloudflare R2, the underlying engine supports S3-compatible signatures. However, UI features are tailored for R2.

== Screenshots ==

1. The Industrial Upload Console with Dual-Zone interaction.
2. Bucket Management interface with one-click connection.

== Changelog ==

= 1.1.0 =
*   Added: Single bucket limit for Free version with PRO-tier promotional UI.
*   Fixed: AWS V4 Signature physical bucket name mismatch.
*   Improved: REST API security with Nonce validation.
*   I18n: Full internationalization support with POT template.

= 1.0.0 =
*   Initial release.