<?php
/**
 * EEZZ PIC2CLD - 管理后台终端实现 (单桶限制与商业增强版)
 * 路径：wp-content/plugins/eezz-pic2cld/eezzpic2cld-admin.php
 */

if (!defined('ABSPATH')) exit;

class EEZZ_PIC2CLD_Admin {
    public function __construct() {
        // 【精确修复】物理确保依赖引擎已加载，防止致命错误
        if (!class_exists('EEZZ_PIC2CLD_Engine')) return;

        add_action('admin_menu', [$this, 'add_menus']);
    }

    public function add_menus() {
        $slug = 'eezzpic2cld-console';
        
        // 物理注册主菜单，权限：manage_options
        add_menu_page(
            __( 'EEZZ Upload', 'eezz-pic2cld' ), 
            __( 'EEZZ Upload', 'eezz-pic2cld' ), 
            'manage_options', 
            $slug, 
            [$this, 'render_console'], 
            'dashicons-cloud-upload', 
            60
        );

        add_submenu_page(
            $slug, 
            __( 'Bucket Management', 'eezz-pic2cld' ), 
            __( 'Bucket Management', 'eezz-pic2cld' ), 
            'manage_options', 
            'eezzpic2cld-buckets', 
            [$this, 'render_buckets']
        );
    }

    /**
     * 【内核功能】左右双域上传终端
     */
    public function render_console() {
        $buckets = get_option('eezzpic2cld_buckets', []);
        if (empty($buckets)) {
            echo '<div class="wrap"><h1>⚡ ' . __( 'EEZZ Upload Console', 'eezz-pic2cld' ) . '</h1><div class="notice notice-warning"><p>' . __( 'Please go to "Bucket Management" to add at least one R2 bucket first.', 'eezz-pic2cld' ) . '</p></div></div>';
            return;
        }
        ?>
        <style>
            .ezcld-wrap { display: flex; gap: 20px; margin-top: 20px; align-items: flex-start; }
            .ezcld-zone { flex: 1; background: #fff; border: 2px dashed #ccd0d4; border-radius: 12px; padding: 30px; text-align: center; min-height: 450px; position: relative; }
            .zone-title { font-weight: 900; color: #1e293b; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px; font-size: 16px; }
            .crop-preview-container { width: 100%; height: 320px; background: #f1f5f9; margin-bottom: 15px; border-radius: 8px; overflow: hidden; display: flex; align-items: center; justify-content: center; }
            #crop-target { max-width: 100%; }
            #batch-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr)); gap: 10px; margin-top: 15px; max-height: 300px; overflow-y: auto; padding: 10px; background: #f8fafc; border-radius: 8px; }
            .btn-action { background: #2271b1; color: #fff; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; width: 100%; font-weight: bold; transition: 0.3s; }
            .btn-action:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            .btn-action:disabled { background: #ccc; cursor: not-allowed; transform: none; }
            .upload-progress { margin-top: 10px; font-size: 12px; font-weight: bold; color: #10b981; }
        </style>

        <div class="wrap">
            <h1>⚡ <?php _e( 'EEZZ PIC2CLD Industrial Console', 'eezz-pic2cld' ); ?></h1>
            
            <div style="background:#fff; padding:20px; border-radius:12px; border:1px solid #e2e8f0; margin-top:15px; display:flex; align-items:center; gap:15px;">
                <strong style="font-size:14px; color:#475569;"><?php _e( 'Target Bucket:', 'eezz-pic2cld' ); ?></strong>
                <select id="active-bucket" style="min-width:200px; height:40px; border-radius:8px;">
                    <?php foreach($buckets as $id => $b): ?>
                        <option value="<?php echo esc_attr($id); ?>">
                            <?php echo esc_html($b['name']); ?> (<?php echo esc_html($b['physical_name'] ?? __( 'Not set', 'eezz-pic2cld' )); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="ezcld-wrap">
                <div class="ezcld-zone" style="border-color: #d97706;">
                    <div class="zone-title" style="color: #d97706;"><?php _e( '✂️ Crop & Refine (Single)', 'eezz-pic2cld' ); ?></div>
                    <div class="crop-preview-container">
                        <img id="crop-target" src="" style="display:none;">
                        <div id="crop-empty-hint" style="color:#94a3b8;"><?php _e( 'Please select a single image', 'eezz-pic2cld' ); ?></div>
                    </div>
                    <input type="file" id="single-file" accept="image/*" style="display:none">
                    <button class="button button-large" onclick="document.getElementById('single-file').click()"><?php _e( '📂 Select Image', 'eezz-pic2cld' ); ?></button>
                    <button id="upload-crop" class="btn-action" style="margin-top:15px; display:none; background:#d97706;"><?php _e( 'Confirm & Sync to R2', 'eezz-pic2cld' ); ?></button>
                </div>

                <div class="ezcld-zone" style="border-color: #10b981;">
                    <div class="zone-title" style="color: #10b981;"><?php _e( '📦 Industrial Batch (No Crop)', 'eezz-pic2cld' ); ?></div>
                    <div id="drop-area" style="padding:60px 20px; background:#f8fafc; border-radius:12px; border:2px dashed #cbd5e1; cursor:pointer;">
                        <span style="font-size:14px; color:#64748b;"><?php _e( 'Drag multiple images or click to select', 'eezz-pic2cld' ); ?></span>
                    </div>
                    <input type="file" id="batch-files" multiple accept="image/*" style="display:none">
                    <div id="batch-list"></div>
                    <div id="batch-status" class="upload-progress"></div>
                    <button id="upload-batch" class="btn-action" style="margin-top:15px; display:none; background:#10b981;"><?php _e( 'Start Industrial Sync', 'eezz-pic2cld' ); ?></button>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($){
            let cropper;
            const bidSelect = $('#active-bucket');

            $('#single-file').on('change', function(e){
                const file = e.target.files[0];
                if(!file) return;
                const reader = new FileReader();
                reader.onload = (ev) => {
                    $('#crop-empty-hint').hide();
                    $('#crop-target').attr('src', ev.target.result).show();
                    if(cropper) cropper.destroy();
                    cropper = new Cropper(document.getElementById('crop-target'), { 
                        viewMode: 1, 
                        dragMode: 'move',
                        autoCropArea: 0.8
                    });
                    $('#upload-crop').show();
                };
                reader.readAsDataURL(file);
            });

            $('#upload-crop').click(function(){
                const btn = $(this);
                btn.prop('disabled', true).text('<?php echo esc_js( __( 'Syncing...', 'eezz-pic2cld' ) ); ?>');
                cropper.getCroppedCanvas({ maxWidth: 2048 }).toBlob(async (blob) => {
                    const fd = new FormData();
                    fd.append('file', blob, 'cropped.jpg');
                    fd.append('bucket_id', bidSelect.val());
                    
                    try {
                        // 【精确修复】使用 esc_url 确保 REST URL 输出安全
                        const res = await fetch('<?php echo esc_url( rest_url( 'eezzpic2cld/v1/upload' ) ); ?>', {
                            method: 'POST',
                            headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                            body: fd
                        });
                        const data = await res.json();
                        if(data.success) { 
                            alert('<?php echo esc_js( __( '✅ Image synced to cloud successfully', 'eezz-pic2cld' ) ); ?>'); 
                            location.reload(); 
                        } else { 
                            throw new Error(data.message || '<?php echo esc_js( __( 'R2 Sync Failed', 'eezz-pic2cld' ) ); ?>'); 
                        }
                    } catch(err) {
                        alert('❌ ' + err.message);
                        btn.prop('disabled', false).text('<?php echo esc_js( __( 'Confirm & Sync to R2', 'eezz-pic2cld' ) ); ?>');
                    }
                }, 'image/jpeg', 0.9);
            });

            const dropArea = $('#drop-area');
            const batchInput = $('#batch-files');
            let batchQueue = [];

            dropArea.on('click', () => batchInput.click());
            batchInput.on('change', function(){
                batchQueue = Array.from(this.files);
                $('#batch-list').html(batchQueue.map(f => `<div style="aspect-ratio:1; background:#eee; border-radius:6px; overflow:hidden;"><img src="${URL.createObjectURL(f)}" style="width:100%; height:100%; object-fit:cover;"></div>`).join(''));
                $('#upload-batch').show();
            });

            $('#upload-batch').click(async function(){
                const btn = $(this);
                const statusBox = $('#batch-status');
                btn.prop('disabled', true);
                
                for (let i = 0; i < batchQueue.length; i++) {
                    statusBox.text('<?php echo esc_js( __( 'Uploading image', 'eezz-pic2cld' ) ); ?> ' + (i+1) + ' / ' + batchQueue.length + '...');
                    const fd = new FormData();
                    fd.append('file', batchQueue[i]);
                    fd.append('bucket_id', bidSelect.val());
                    
                    // 【精确修复】使用 esc_url 确保 REST URL 输出安全
                    await fetch('<?php echo esc_url( rest_url( 'eezzpic2cld/v1/upload' ) ); ?>', {
                        method: 'POST',
                        headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                        body: fd
                    });
                }
                alert('<?php echo esc_js( __( '✅ Batch sync completed', 'eezz-pic2cld' ) ); ?>');
                location.reload();
            });
        });
        </script>
        <?php
    }

    /**
     * 【内核功能】存储桶管理：单桶限制与商业逻辑
     */
    public function render_buckets() {
        $buckets = get_option('eezzpic2cld_buckets', []);
        $has_bucket = (count($buckets) >= 1);

        // 【精确修复】删除逻辑改用 wp_verify_nonce 提高环境兼容性
        if (isset($_GET['del_bucket']) && wp_verify_nonce($_GET['_wpnonce'], 'del_b_' . $_GET['del_bucket'])) {
            unset($buckets[sanitize_text_field($_GET['del_bucket'])]);
            update_option('eezzpic2cld_buckets', $buckets);
            echo '<div class="updated"><p>' . __( '✅ Bucket removed successfully.', 'eezz-pic2cld' ) . '</p></div>';
            $has_bucket = false;
        }

        // 【精确修复】添加逻辑改用 wp_verify_nonce，彻底解决 "Link Expired" 问题
        if (isset($_POST['add_bucket']) && isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'ezcld_add_b')) {
            if ($has_bucket) {
                echo '<div class="error"><p>' . __( 'Free version supports 1 active bucket. Please remove existing one to add new.', 'eezz-pic2cld' ) . '</p></div>';
            } else {
                $b_name = sanitize_text_field($_POST['b_name']);
                $key_id = sanitize_title($b_name);
                $buckets[$key_id] = [
                    'name'          => $b_name,
                    'physical_name' => sanitize_text_field($_POST['b_physical_name']),
                    'id'            => sanitize_text_field($_POST['b_id']),
                    'key'           => sanitize_text_field($_POST['b_key']),
                    'sec'           => sanitize_text_field($_POST['b_sec']),
                    'pub'           => esc_url_raw($_POST['b_pub'])
                ];
                update_option('eezzpic2cld_buckets', $buckets);
                echo '<div class="updated"><p>' . __( '✅ New bucket is ready.', 'eezz-pic2cld' ) . '</p></div>';
                $has_bucket = true;
            }
        }
        ?>
        <div class="wrap">
            <h1>📂 <?php _e( 'R2 Bucket Management Core', 'eezz-pic2cld' ); ?></h1>
            <div style="display: grid; grid-template-columns: 1.5fr 1fr; gap: 20px; margin-top: 20px; align-items: start;">
                <div class="postbox" style="border-radius:12px; overflow:hidden;">
                    <div style="padding:15px; background:#f8fafc; border-bottom:1px solid #eee;"><h2 style="margin:0; font-size:14px;"><?php _e( 'Active Storage Node', 'eezz-pic2cld' ); ?></h2></div>
                    <div style="padding:15px;">
                        <table class="wp-list-table widefat fixed striped">
                            <thead><tr><th><?php _e( 'Alias', 'eezz-pic2cld' ); ?></th><th><?php _e( 'Physical Name', 'eezz-pic2cld' ); ?></th><th>Account ID</th><th>Public URL</th><th width="80"><?php _e( 'Action', 'eezz-pic2cld' ); ?></th></tr></thead>
                            <tbody>
                                <?php if($buckets): foreach($buckets as $kid => $b): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($b['name']); ?></strong></td>
                                    <td><code><?php echo esc_html($b['physical_name'] ?? __( 'Not set', 'eezz-pic2cld' )); ?></code></td>
                                    <td><small><?php echo esc_html($b['id']); ?></small></td>
                                    <td><small><?php echo esc_html($b['pub']); ?></small></td>
                                    <td><a href="<?php echo wp_nonce_url('?page=eezzpic2cld-buckets&del_bucket='.$kid, 'del_b_'.$kid); ?>" style="color:#d63638; text-decoration:none;" onclick="return confirm('<?php echo esc_js( __( 'Remove this bucket?', 'eezz-pic2cld' ) ); ?>')"><?php _e( 'Remove', 'eezz-pic2cld' ); ?></a></td>
                                </tr>
                                <?php endforeach; else: ?>
                                <tr><td colspan="5"><?php _e( 'No bucket connected.', 'eezz-pic2cld' ); ?></td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="postbox" style="border-radius:12px; overflow:hidden;">
                    <?php if (!$has_bucket): ?>
                        <div style="padding:15px; background:#f8fafc; border-bottom:1px solid #eee;"><h2 style="margin:0; font-size:14px;"><?php _e( '➕ Connect New R2 Bucket', 'eezz-pic2cld' ); ?></h2></div>
                        <div style="padding:20px;">
                            <form method="post">
                                <?php wp_nonce_field('ezcld_add_b'); ?>
                                <p><label><strong><?php _e( 'Bucket Alias', 'eezz-pic2cld' ); ?></strong></label><br><input type="text" name="b_name" required style="width:100%; border-radius:6px;"></p>
                                <p><label><strong><?php _e( 'R2 Physical Name', 'eezz-pic2cld' ); ?></strong></label><br><input type="text" name="b_physical_name" required style="width:100%; border-radius:6px;"></p>
                                <p><label><strong>Account ID</strong></label><br><input type="text" name="b_id" required style="width:100%; border-radius:6px;"></p>
                                <p><label><strong>Access Key</strong></label><br><input type="text" name="b_key" required style="width:100%; border-radius:6px;"></p>
                                <p><label><strong>Secret Key</strong></label><br><input type="password" name="b_sec" required style="width:100%; border-radius:6px;"></p>
                                <p><label><strong>Public URL</strong></label><br><input type="text" name="b_pub" required style="width:100%; border-radius:6px;"></p>
                                <hr>
                                <input type="submit" name="add_bucket" class="button button-primary button-large" style="width:100%; height:45px;" value="<?php echo esc_attr( __( 'Save & Mount', 'eezz-pic2cld' ) ); ?>">
                            </form>
                        </div>
                    <?php else: ?>
                        <div style="padding:40px 20px; text-align:center; background:#fff;">
                            <div style="font-size:54px; margin-bottom:20px;">🚀</div>
                            <h2 style="color:#1e293b; margin-top:0;"><?php _e( 'Unlock Professional Version', 'eezz-pic2cld' ); ?></h2>
                            <p style="color:#64748b; line-height:1.6; font-size:14px;"><?php _e( 'You have reached the single bucket limit of the Free Version. Upgrade to PRO for enterprise features.', 'eezz-pic2cld' ); ?></p>
                            
                            <ul style="text-align:left; display:inline-block; margin:20px 0; color:#334155; font-size:13px; list-style:none; padding:0;">
                                <li style="margin-bottom:8px;">✅ <strong><?php _e( 'Unlimited Buckets:', 'eezz-pic2cld' ); ?></strong> <?php _e( 'Multi-region redundancy.', 'eezz-pic2cld' ); ?></li>
                                <li style="margin-bottom:8px;">✅ <strong><?php _e( 'Auto-Migration:', 'eezz-pic2cld' ); ?></strong> <?php _e( 'Move existing media with one click.', 'eezz-pic2cld' ); ?></li>
                                <li style="margin-bottom:8px;">✅ <strong><?php _e( 'WebP Optimization:', 'eezz-pic2cld' ); ?></strong> <?php _e( 'Next-gen image compression.', 'eezz-pic2cld' ); ?></li>
                            </ul>

                            <a href="https://eezz.net/uncategorized/172/eezz-pic2cld-eezz-r2-manager/" target="_blank" class="button button-primary button-large" style="width:100%; height:45px; line-height:43px; font-weight:bold;">
                                <?php _e( 'Get PRO Version Now', 'eezz-pic2cld' ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

// 【精确修复】物理触发类实例化，确保注册生效
if (is_admin()) {
    new EEZZ_PIC2CLD_Admin();
}