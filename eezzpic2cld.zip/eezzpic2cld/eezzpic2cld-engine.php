<?php
/**
 * EEZZ PIC2CLD - R2 签名与 URL 接管引擎 (引擎加固版)
 * 路径：wp-content/plugins/eezz-pic2cld/eezzpic2cld-engine.php
 */

if (!defined('ABSPATH')) exit;

class EEZZ_PIC2CLD_Engine {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance == null) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // 物理挂载过滤器，接管媒体库 URL 展示
        add_filter('wp_get_attachment_url', [$this, 'hijack_url'], 101, 2);
        add_filter('wp_prepare_attachment_for_js', [$this, 'fix_admin_preview'], 101, 3);
    }

    /**
     * 执行 AWS V4 签名并上传至 R2[cite: 14]
     */
    public function r2_request($method, $path, $body, $bucket) {
        $host = "{$bucket['id']}.r2.cloudflarestorage.com";
        $amz_date = gmdate('Ymd\THis\Z'); 
        $date_st = gmdate('Ymd');
        $sha = hash('sha256', $body); 
        $scope = "{$date_st}/auto/s3/aws4_request";
        
        // 【精确修复】物理对齐真实桶名[cite: 14]
        $real_bucket = $bucket['physical_name'];
        $clean_path = ltrim($path, '/');
        $encoded_path = str_replace('%2F', '/', rawurlencode($clean_path));
        
        $canonical_uri = '/' . $real_bucket . '/' . $encoded_path;
        
        $canonical = "{$method}\n{$canonical_uri}\n\nhost:{$host}\nx-amz-date:{$amz_date}\n\nhost;x-amz-date\n{$sha}";
        $string_to_sign = "AWS4-HMAC-SHA256\n{$amz_date}\n{$scope}\n" . hash('sha256', $canonical);
        
        $k = hash_hmac('sha256', "aws4_request", hash_hmac('sha256', "s3", hash_hmac('sha256', "auto", hash_hmac('sha256', $date_st, "AWS4".$bucket['sec'], true), true), true), true);
        $signature = hash_hmac('sha256', $string_to_sign, $k);
        
        $auth = "AWS4-HMAC-SHA256 Credential={$bucket['key']}/{$scope}, SignedHeaders=host;x-amz-date, Signature={$signature}";

        // 【精确修复】增加物理错误拦截，防止网络故障抛错[cite: 14]
        $res = wp_remote_request("https://{$host}/{$real_bucket}/{$encoded_path}", [
            'method'  => $method,
            'body'    => $body,
            'timeout' => 60,
            'headers' => [
                'Host' => $host,
                'X-Amz-Date' => $amz_date,
                'X-Amz-Content-Sha256' => $sha,
                'Authorization' => $auth,
                'Content-Type' => 'image/jpeg'
            ]
        ]);

        if (is_wp_error($res)) {
            return 500; // 物理映射为服务器内部错误[cite: 14]
        }

        return wp_remote_retrieve_response_code($res);
    }

    public function hijack_url($url, $id) {
        if ($path = get_post_meta($id, '_ezcld_path', true)) {
            $buckets = get_option('eezzpic2cld_buckets', []);
            $bid = get_post_meta($id, '_ezcld_bid', true);
            $pub = $buckets[$bid]['pub'] ?? '';
            return rtrim($pub, '/') . '/' . ltrim($path, '/');
        }
        return $url;
    }

    public function fix_admin_preview($res, $att) {
        if (get_post_meta($att->ID, '_ezcld_path', true)) {
            // 【精确修复】传入原始 URL 确保降级兼容性[cite: 14]
            $url = $this->hijack_url($res['url'], $att->ID);
            $res['url'] = $res['link'] = $url;
            if (isset($res['sizes'])) {
                foreach ($res['sizes'] as &$size) { $size['url'] = $url; }
            }
        }
        return $res;
    }
}

// 【精确修复】物理初始化引擎[cite: 14]
EEZZ_PIC2CLD_Engine::get_instance();