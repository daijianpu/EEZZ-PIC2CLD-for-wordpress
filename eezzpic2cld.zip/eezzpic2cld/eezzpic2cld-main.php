<?php
/*
Plugin Name: EEZZ PIC2CLD Professional
Plugin URI: https://eezz.net/uncategorized/172/eezz-pic2cld-eezz-r2-manager/
Description: Industrial-grade R2 cloud storage core. Supports multi-bucket management, cropping/batch upload modes, and full media library integration.
Version: 1.1.0
Author: EEZZ.NET
Author URI: https://eezz.net/
Tested up to: 6.5
Requires at least: 5.8
Requires PHP: 7.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: eezz-pic2cld
Domain Path: /languages
*/

if (!defined('ABSPATH')) exit;

// 【精确修复】定义物理动态路径，解决改名失效问题
define('EZCLD_VERSION', '1.1.0');
define('EZCLD_PATH', plugin_dir_path(__FILE__));
define('EZCLD_URL', plugin_dir_url(__FILE__));

/**
 * 物理加载组件
 * 理由：确保所有逻辑模块被正确引入
 */
$ezcld_modules = [
    'eezzpic2cld-engine.php',
    'eezzpic2cld-api.php',
    'eezzpic2cld-admin.php'
];

foreach ($ezcld_modules as $module) {
    if (file_exists(EZCLD_PATH . $module)) {
        require_once EZCLD_PATH . $module;
    }
}

// 插件激活：初始化配置池
register_activation_hook(__FILE__, function() {
    if (!get_option('eezzpic2cld_buckets')) {
        update_option('eezzpic2cld_buckets', []);
    }
});

// 挂载静态资源：Cropper.js
add_action('admin_enqueue_scripts', function($hook) {
    // 物理校验：仅在插件页面加载资源，防止后台污染
    if (strpos($hook, 'eezzpic2cld') === false) return;
    
    // 【精确修复】将外部 CDN 资源改为引用插件本地资源
    // 理由：WordPress.org 严禁插件直接加载第三方 CDN 资源，必须物理包含在插件包内
    wp_enqueue_style('ezcld-cropper', EZCLD_URL . 'assets/cropper.min.css', array(), '1.5.13');
    wp_enqueue_script('ezcld-cropper-js', EZCLD_URL . 'assets/cropper.min.js', array(), '1.5.13', true);
});

// 物理加载语言包
add_action('init', function() {
    load_plugin_textdomain('eezz-pic2cld', false, dirname(plugin_basename(__FILE__)) . '/languages');
});