<?php
/**
 * EEZZ PIC2CLD - REST API 上传处理网关 (网关加固版)
 * 路径：wp-content/plugins/eezz-pic2cld/eezzpic2cld-api.php
 */

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function() {
    register_rest_route('eezzpic2cld/v1', '/upload', [
        'methods' => 'POST',
        'callback' => 'ezcld_handle_api_upload',
        // 物理权限校验：确保仅具备管理权限的用户可调用
        'permission_callback' => function() { 
            return (bool) current_user_can('manage_options'); 
        }
    ]);
});

function ezcld_handle_api_upload($request) {
    $files = $request->get_file_params();
    
    // 【精确修复】增加输入安全过滤
    $bid   = sanitize_text_field($request->get_param('bucket_id'));
    $buckets = get_option('eezzpic2cld_buckets', []);
    
    // 存储桶有效性物理校验
    if (!isset($buckets[$bid])) {
        return new WP_Error('err', __( 'Invalid storage bucket.', 'eezz-pic2cld' ));
    }
    $bucket = $buckets[$bid];
    
    // 文件负载完整性校验
    if (!isset($files['file'])) {
        return new WP_Error('no_file', __( 'No file data received.', 'eezz-pic2cld' ));
    }

    // 【新增代码】动态获取文件类型以增强媒体库兼容性
    $file_info = wp_check_filetype($files['file']['name'], null);
    $tmp_file = $files['file']['tmp_name'];
    $filename = "EZ-" . wp_date('His') . "-" . bin2hex(random_bytes(2)) . ".jpg";
    $r2_path  = "eezz/" . wp_date('Ymd') . "/" . $filename;

    $engine = EEZZ_PIC2CLD_Engine::get_instance();
    $file_content = file_get_contents($tmp_file);
    
    // 发起 R2 同步请求
    $res_code = $engine->r2_request('PUT', $r2_path, $file_content, $bucket);

    if ($res_code === 200) {
        $img_info = @getimagesize($tmp_file);
        
        // 【精确修复】物理插入附件记录，使用动态 MIME 类型
        $aid = wp_insert_attachment([
            'post_mime_type' => $file_info['type'] ?: 'image/jpeg', 
            'post_title'     => $filename,
            'post_status'    => 'inherit',
            'guid'           => rtrim($bucket['pub'], '/') . '/' . $r2_path
        ]);

        // 【精确修复】增强异常状态拦截
        if (is_wp_error($aid) || !$aid) {
            return $aid ? $aid : new WP_Error('insert_fail', __( 'Failed to create attachment record.', 'eezz-pic2cld' ));
        }

        /**
         * 附件元 metadata 补全
         */
        wp_update_attachment_metadata($aid, [
            'width'  => $img_info[0] ?? 1200,
            'height' => $img_info[1] ?? 800,
            'file'   => $r2_path, 
            'sizes'  => []
        ]);

        // 记录云端物理路径与存储桶映射 Meta
        update_post_meta($aid, '_ezcld_path', $r2_path);
        update_post_meta($aid, '_ezcld_bid', $bid);

        return [
            'success' => true, 
            'id'      => $aid, 
            'url'     => rtrim($bucket['pub'], '/') . '/' . $r2_path
        ];
    }
    
    return new WP_Error('fail', sprintf( __( 'R2 synchronization failed, Error Code: %d', 'eezz-pic2cld' ), $res_code ));
}